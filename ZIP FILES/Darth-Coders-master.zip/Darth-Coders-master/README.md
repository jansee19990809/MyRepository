# Darth-Coders

Team Name:	Darth Coders

Team Members:	See, Jan Wilbert
		Francisco, Isiah Frederico
		Menchate, Arvi
		Maico, Bryan

Application Description:
		It is a computer-based applicattion that translates the word being entered to all the languages and other dialects in the Philippines. It includes alto interctive activities to thorougly enhance the learning experience of the user.

Installation Guide:

		The application is a simple executable (.exe) file. All you need to do is to copy the file into the desired directory on your computer devices such as laptops or desktops then run the application just like to usual way of double-clicking it.

Application Guidelines:

- Language Used: C#
- IDE Used: Visual Studio 2019 Community
- Database Used: SQL
- API Used: Speech/Voice Recognition

Citations or References:

Functionalities Referred:

https://www.youtube.com/watch?v=KR0-UYUGYgA

https://www.youtube.com/watch?v=AB9lfHDOe5U

https://dashboard.nexmo.com/sign-up

Ideas Referrred:

https://www.merriam-webster.com/

http://www.visualdictionaryonline.com/

