<?php


function redirect($location){ // redirect to the page
       	return header("Location: {$location}");
    }
    
    function set_message($message){ //setting message like error
        if(!empty($message)){
          $_SESSION['message'] = $message; // set this message if not empty
        }
        else{
            $message = ""; // no message
        }
   }


///=====================Validation Functions=============================//


function validation_error($error_message){ // itong validation error is isang method pwede mo syang gamitin pang echo ng error
    // use this delimiter to display $error using echo, delimiter no space in the end
    $error_message = <<<DELIMITER
    <div class="alert alert-danger" role="alert">$error_message</div> 
    DELIMITER; 
    return $error_message; // return error message
 }

 // ============================== end of the validation error
	
	
function login_user(){
if($_SERVER['REQUEST_METHOD'] == "POST"){

 

    if(empty($_POST['user_name']) && empty($_POST['password'])){
        echo "Both Fields are required";
    }
    else{
  
        $username = $_POST['user_name'];
        $password = $_POST['password'];
        $sql = "SELECT * FROM users WHERE user_name = '".escape($username)."' AND password = '".escape($password)."' ";
        $result = query($sql); 
        if(mysqli_num_rows($result) > 0){
			
            
        $row = mysqli_fetch_array($result);
        
        $id = $row['id'];
        $name = $row['first_name'];
        $lname = $row['last_name'];
        $_SESSION['id'] = $id;
        $_SESSION['firstname'] = $name;
        $_SESSION['lastname'] = $lname;
		redirect("index.php");
       
            
        }
        else{
            
            echo validation_error("Username or Password are incorrect");
        }
        
    }
   
}

} // end of the login user ==========================







// register =========================================


//====================================If Username and Email Exist==============================//

function email_exist($email){ // method ito para magvalidate if may existing email na sa database
$sql = "SELECT StudentID FROM student WHERE email = '$email'";
$result = query($sql); // itong query($sql); ay isang helper function tignan mo sya sa db.php ang ginagwa nitng function neto pra magfetch ng data sa database
if(row_count($result) == 1){ // need nito para 1 row lang ang kinukuhang data sa database
    return true; // return true if 1 row lang ang nafetch nyang data
}else{
    return false; // return false pag walang nakuhang data
}
}

function username_exist($username){ 
$sql = "SELECT StudentID FROM student WHERE user_name = '$username'"; // username or id in select is ok choose 
$result = query($sql); // itong query($sql); ay isang helper function tignan mo sya sa db.php ang ginagwa nitng function neto pra magfetch ng data sa database
if(row_count($result) > 0){  //return true if the result row count is greater than  0
    return true; // return fetch data
}else{
    return false; // return false
}
}





function validate_user(){
 $error = []; // nagdeclare ako ng array na variable pra lalagyanan ng mga erro ko kung meron man

if($_SERVER['REQUEST_METHOD'] == "POST"){
    $username = $_POST['user_name']; // set the variable of username itong nasaloob ng post is makukuha mo sya sa <input name="user_name">
    $firstname = $_POST['first_name'];
    $lastname = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

if(empty($username)){ // empty build in method to ng php if walang laman then magbabato ako ng error
    $error[] = "Username Field cannot be empty"; // mag seset ako ng error gamit array
}
if(empty($firstname)){
    $error[] = "Firstname Field cannot be empty"; // mag seset ako ng error gamit array
}
if(empty($lastname)){
    $error[] = "Lastname Field cannot be empty"; // mag seset ako ng error gamit array
}
if(empty($email)){
    $error[] = "Email Field cannot be empty"; // mag seset ako ng error gamit array
}
if(empty($password)){
    $error[] = "Password Field cannot be empty"; // mag seset ako ng error gamit array
}
if(empty($confirm_password)){
    $error[] = "Confirm Password Field cannot be empty"; // mag seset ako ng error gamit array
}
if($password !== $confirm_password){ // mag seset ako ng error gamit array
    $error[] = "Password did not match";
}
    

    if(!empty($error)){ // if not empty or may laman ang error array variable iloloop ko sya
        foreach($error as $error){ // setting loop
            echo validation_error($error); // magbabato ako ng error gamit ang validation_error na ginawa ko tapos lalagay ko sa loob yong array na error namay laman na sinet ko if empty or not equal
        }                                   // need ng echo para madisplay ang messahge kasi hindi ko nilgyan ng echo sa ginawa kong validation_error(); sa taas
    }
    else{ // if walang error tatawagin ko yong ginawa kong function sa baba na register user
        // register user if no error
        // then called register_user function 
        if(register_user($username, $firstname, $lastname, $email, $password)){ //itong argument na username at etc nakadeclare to sa taas tapos ipapasa ko yong variable sa ginawa kong register_user() fucntion
            set_message("<p class='bg-success text-center'>Please Check your Email for activation link</p>");
            redirect("login.php"); // using header to redirect it is called helper function in db file
        }
        else{
            set_message("<p class='bg-danger text-center'>Sorry we could not register the user</p>");
            redirect("register.php");
        } // babalik sya sa login page kapag may error sa register mo


    }

    
}
}

function register_user($username, $firstname, $lastname, $email, $password){ // gagamitin ko itong mga variable para magvalidate and maginsert sa database
// note itong mga usernme firstname at etc. nasa validate_user() function to
if(email_exist($email)){ //return false if email exist
    return false;
}
else if(username_exist($username))
{
    return false; // return false if username exist
}

else{ // if walang error iinsert ko yong mga tinaype ng user sa input gamit yong mga variable na pinasa ko
    $sql = "INSERT INTO users (user_name, first_name, last_name, email, password)";
    $sql .=" VALUES ('$username', '$firstname', '$lastname', '$email', '$password')";
    $result = query($sql);
    confirm($result); // confirm nasa db.php to if may mali sa syntax mo sa sql malalaman mo error kaya kailanganan to

    return true; // return true para gumana yong function naten
}
}












?>