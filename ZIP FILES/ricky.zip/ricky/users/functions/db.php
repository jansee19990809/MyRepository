<?php


$con = mysqli_connect("localhost", "root", "", "ricky");


// helper function 


function query($query) // connection and query
{
    global $con;
    return mysqli_query($con, $query);
}

function row_count($result){
    return mysqli_num_rows($result);
}

function confirm($result)
{
    global $con;
    if(!$result){
        die("Error description:" . mysqli_error($con));
    }
}

function fetch_array($result){ //fetch data from database
    global $con;
    return mysqli_fetch_array($result);
}

function escape($string) // escape character or string
{
    global $con; // global this connection
    return mysqli_real_escape_string($con, $string);
}



?>